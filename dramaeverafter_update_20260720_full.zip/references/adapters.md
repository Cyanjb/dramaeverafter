# DramaEverAfter source adapters
Last verified: 2026-07-17. Sites change; verify structure on first fetch each session.

## 1. ReelShort actor/actress tag pages
- URL: `https://www.reelshort.com/tags/movie-actors/{slug}-movies-{id}` (or movie-actresses)
- Reachable from bash with a desktop User-Agent (contrary to older skill note).
- Data: embedded `__NEXT_DATA__` JSON at `props.pageProps.tagBooks`.
  - `books[]`: book_title, read_count (views), chapter_count (episodes), special_desc (synopsis), book_id
  - `total_items`, `page`, `page_size` (10). Pagination: append `/2`, `/3`... (NOT ?page=)
  - Map book_id to slug via hrefs: `/movie/{slug}-{24-hex-id}`
- Feeds: people, titles, availability, credits (role=actor), snapshots.

## 2. ReelShort movie detail pages
- URL: `https://www.reelshort.com/movie/{slug}-{id}`
- `__NEXT_DATA__` contains a book object (hunt for dict with book_title + read_count).
- chapter_count often absent on detail pages; leave episode_count blank rather than 0.
- 404 = delisted title. Do not add; log for review.

## 3. ReelShort fandom blog (WordPress, open REST API) — richest source
- Base: `https://www.reelshort.com/fandom/wp-json/wp/v2/posts`
- Params: `?categories={id}&per_page=100&page={n}&_fields=id,title,link,content`
- Categories (2026-07-17): 3 = Movie Cast List (1,543), 1 = General Topic (1,130),
  4 = Top Movie Stories (343), 5 = Movie Streaming Guide (52).
- Cast extraction patterns (use ONLY these; prose "played by" captures junk):
  - h2/h3 headings: `Actor Name as Character Name`
  - Inline: `Character Name (Actor: Actor Name)` / `(Actress: ...)`
  - Validate actor names: 2-4 capitalized words, reject pronoun/article starts.
- Drama identity: most-frequent `/movie/{slug}-{id}` link in the article, never the headline text.
- Bios: sentences containing the actor's full name plus a career keyword
  (actor, known for, starred, born, based, trained...). Skip character-description sentences.
- Socials: NOT present in fandom articles as of 2026-07-17. Needs another source.
- Streaming guides mention platforms rhetorically ("Is X on Netflix?"); a mention is NOT
  availability. Only "official full episodes on YouTube" claims are worth a review flag.

## 4. Blocked or rejected sources (tested 2026-07-17)
- Reddit: 403 from bash (old. and www.). Reachable via Claude's web search/fetch tools only.
- fandom.com wikis: 403 from bash; ReelShort runs its own fandom section anyway (see 3).
- IMDb: bot-blocked from bash; works via search/fetch tools. Use for per-actor verification.
- Dailymotion: reachable, public API at api.dailymotion.com, but content is pirated
  re-uploads with junk metadata. NEVER link or ingest. Off-brand for a where-to-watch site.
- TikTok: serves stub pages to bash. /discover/ pages surface via web search and can
  reveal actor handles for the socials column; manual/per-actor only.

## Screenshot intake (Reddit/Facebook identification threads)
- Cyan drops a screenshot; read title guesses and actor names from the thread text.
- Anything ambiguous goes to match_queue.csv with the screenshot description as evidence.
- Never auto-merge a fan identification; needs_check until Cyan confirms.

## Merge policy reminders (see data/CONVENTIONS.md)
- Match key: platform_id + title_as_listed (case-insensitive). Slug near-match check:
  compare with all hyphens removed before creating any new title row.
- Fill blanks only; never overwrite non-blank fields without logging a conflict.
- Near-identical actor names (blog typos are common): hold the rarer spelling out of
  people.csv, log to match_queue. Slugs are permanent; a wrong actor page is worse
  than a one-run delay.

## 5. My Drama (Holywater) — full catalog adapter (added 2026-07-17)
- Sitemap: `https://my-drama.com/sitemap.xml` -> ~187 `/series/{slug}-{uuid}` URLs. Reachable from bash with desktop UA.
- Data: Next.js streamed payload (`self.__next_f.push` chunks; join, unicode-unescape).
  `"seriesData":{...}` block has: name, slug, description, totalEpisodes, cast (camelCase keys), likes, rating, langs, coverUrl.
- Cast display names: regex `"name":"X","url":"https://my-drama.com/actors/{key}"` pairs in the same payload (from embedded structured data). Actor pages exist at /actors/{key} — unharvested; likely bios/photos for a future run.
- No view counts (likes + rating instead) -> no snapshots rows; view_count left blank.
- My Drama is originals-only: same title text as another platform almost certainly means a DIFFERENT production. Never auto-merge cross-platform title matches; match_queue them.
- ~50 of 173 credited actors overlap the ReelShort roster (US-based Holywater productions); the rest are largely Ukrainian cast (Kyiv productions).

## 6. Platform reachability probe (2026-07-17, from bash, desktop UA)
- OPEN: netshort.com (200, server-rendered /drama/ links + /all-episodes), goodshort.com (200, hydration JSON), vigloo.com (200, sitemaps at /sitemaps/index.xml incl. sitemap-content-en-*.xml), my-drama.com (200 + sitemap).
- BLOCKED: dramabox.com (403 bash; homepage only via fetch tool, /browse and dramaboxdb.com bot-walled), shortmax.com (503), playlet.com (503), anyreel.com (503), stardusttv.com (403), kalostv.com (200 but 3KB JS stub).
- Next adapter candidates in order: vigloo (sitemap = easy), netshort (server-rendered), goodshort (hydration parse).

## 7. CandyJar (Inkitt/Galatea) — full catalog adapter (added 2026-07-17)
- Homepage `https://www.candyjar.com` (bash OK, desktop UA) embeds the FULL catalog in Next.js
  `self.__next_f.push` chunks: 90 unique series (261 rail appearances — dedupe by id).
  Fields per series: id, title, coverUrl, summary. NO episodeCount in rails.
- Sitemaps: robots at candyjar.com (non-www) -> /en/sitemap.xml lists /series/{kebab-title}-{id}.
- Episode counts: fetch each series page, count distinct `"episodeNumber":N` in the payload.
- NO cast data anywhere on web (confirmed; reviews note "actor search limitations"). Titles/availability only.
- Galatea originals (book adaptations): same-name matches on other platforms are DIFFERENT productions; match_queue them.

## 8. Big-platform status (checked 2026-07-17)
- DramaBox: comprehensively bot-walled. Main site, /browse, dramaboxdb.com, and all three official
  mirrors (dramaboxapp.com, dramaboxen.com, dramaboxtv.com) return 403 from bash; fetch tool also
  blocked on everything except the bare homepage. No bulk route. Per-title data only via web
  search snippets. Revisit occasionally; walls change.
- DramaWave: no functioning web catalog found (dramawave.com/.tv/.app all dead or 503). App-only.
  30K+ titles, mostly translated Chinese content — low fit for the English-actor-centric DB anyway.
- Shortical (a.k.a. "Shorticles"): app-only, no web catalog; small operator (Short Entertainment LTD),
  rough user reviews. Low priority.
- GoodShort: OPEN from bash. Server-rendered: /channel/ x8 (browse rails), /drama/ title pages,
  /tag/ x231 on homepage (includes actor-style tags — same shape as ReelShort). No /sitemap.xml (404).
  Enumerate via channels + tags. STRONGEST next adapter among the "big" apps.
- DramaReels (Jan 2026 #1 by downloads): dramareels.app is a GoDaddy Website Builder LANDING PAGE
  (img1.wsimg.com/website-builder-data-prod), not the streaming app. No catalog, no API, sitemap is just
  homepage + /ols/products (GoDaddy store module). App-only distribution. NOT harvestable from web (checked 2026-07-20).

## 9. GoodShort (Singapore New Reading Tech) — full catalog adapter (added 2026-07-17)
- No sitemap (404). Enumerate via `https://www.goodshort.com/dramas/playlets?page=1..187`
  -> ~1853 unique `/drama/{slug}-{numericid}` URLs. Reachable from bash, desktop UA.
- Per drama page: TVSeries JSON-LD block has name, description, numberOfEpisodes, genre, dateCreated (year).
  Views: HTML `Views</p><p ...>375.2K</p>` (already K/M format -> snapshots directly).
  Tropes: `/tag/{trope}-playlets-videos` hrefs on the page. Admit a tag to trope vocab only when it
  appears on >=3 titles (filters junk); recompute tropes.csv title_count after.
- NO cast/actor data on drama pages. Titles + availability + tropes + views only.
- Translated novel adaptations -> same-name matches usually DIFFERENT productions; new collisions go to
  match_queue (9 held this run). Per 2026-07-18 policy: compare, don't blanket-hold.
- Result 2026-07-17: 1828 new titles, 1828 availability rows, 1816 snapshots, 97 new tropes, 9 held.

## 10. Vigloo (KR-origin, intl cast) — full catalog adapter (added 2026-07-20)
- Sitemap index: `https://www.vigloo.com/sitemaps/index.xml` -> per-locale content+video maps. EN catalog = the 5
  `sitemap-content-en-*.xml` -> 198 unique `/en/content/{numericid}` URLs. Reachable from bash, desktop UA.
- Per content page: BOTH LD+JSON (`TVSeries`) and `__NEXT_DATA__ props.pageProps.program`. Clean structured data:
  title, synopsis/description, logLine, genre[] (trope-like), numberOfEpisodes, datePublished/releaseDate (year),
  rating, isOriginal, thumbnailUrl. Cast: LD+JSON `actor[]` (structured names) with `program.casting` string fallback.
- NO view counts (like My Drama) -> no snapshots rows; view_count left blank.
- Originals (`isOriginal:True`, asset ids like KR071P01S01). Cast is INTERNATIONAL, not purely Korean: ~19 of 391
  actors already on the ReelShort/My Drama roster (exact same people; capitalization variants like
  DesLaurier/Deslaurier, Woo-tae/Woo-Tae). Same-English-title as an existing title -> DIFFERENT production;
  create with `-vigloo` slug suffix + match_queue row. Genres admitted to trope vocab at >=3-title threshold.
- Result 2026-07-20: 198 new titles, 198 availability, 369 new people, 418 credits, 18 new tropes, 3 collisions held.

## 11. NetShort (multilingual, huge) — adapter + queue (added 2026-07-20)
- Canonical host is bare `netshort.com` (www 301s). robots: `Crawl-delay: 1`, blocks python-requests/Scrapy UA
  (use desktop UA), disallows /prod-web-api* (the data API). Honor the 1s delay.
- Sitemap index `https://netshort.com/sitemap_netshortcom.xml` -> `site_play_1..35.xml` populated (36-97 empty),
  15000 `/episode/{slug}-{snowflakeid}` URLs each. Strip `-ep-N` and dedupe -> 44,781 distinct SERIES (2026-07-20).
  Snowflake ids are time-ordered: sort desc for newest-first.
- Series page `/drama/{key}` is an EMPTY shell ("Discover 0 short dramas"); real data is only on the base
  `/episode/{key}` page, server-rendered in meta tags: og:title (strip " Online Watch - NetShort"),
  description meta (synopsis, cut at "...Watch"), keywords meta (first item = title, rest = tags/tropes).
- NO cast, NO view counts server-side (playCount only in reviews block; app API blocked). Titles+availability+tropes only.
- MULTILINGUAL: newest titles are heavily ES/PT. Filter: ASCII-only slug (drop `%`-encoded) + English-stopword gate
  on synopsis. ~60% of ASCII candidates pass the English gate.
- Full 44,781 too big for one session (12h+ at 1s delay) and cast-less -> would swamp the actor-centric DB.
  Policy: incremental. `data/netshort_harvest_queue.csv` (series_key,url,status) holds all 44,781 newest-first;
  harvest bounded batches per run and mark done. First batch 2026-07-20.

## 12. Pinedrama (aggregator, English) — adapter + queue (added 2026-07-20)
- Sitemap index `https://pinedrama.com/sitemap.xml` -> `/sitemap/movie.xml` = 10,523 `/dramas/{slug}` series
  (clean slugs, NO numeric id), plus movieplay.xml (29,999 episode URLs) and novel/chapter maps (ignore).
- Per drama page: LD+JSON `TVEpisode` block = clean structured data: name, description (rich synopsis),
  numberOfEpisodes, genre (single), image (poster on v.pinedrama.com). Also FAQPage/BreadcrumbList/Org (ignore).
  Pages are ~195KB and slow (~2-3s each); no crawl-delay declared. English-only content.
- NO cast, NO view counts. Titles + availability + tropes(genre) only.
- HEAVY OVERLAP: ~53% of a 137-title sample collided by name with existing titles -> Pinedrama looks like an
  AGGREGATOR re-hosting mainstream US vertical dramas, not an originals studio. First run held all collisions to
  match_queue per the never-auto-merge rule (73 held). OPEN QUESTION for Cyan: if Pinedrama re-hosts existing
  productions, collisions should become AVAILABILITY rows on the existing title (where-to-watch model), not new
  `-pinedrama` titles. Confirm aggregator status, then convert.
- Incremental: `data/pinedrama_harvest_queue.csv` (slug,url,status) holds all 10,523. First batch 2026-07-20 (137).

## 13. Platforms probed 2026-07-20, no harvest
- starshort.com: serves a Cloudflare content-signals robots policy (ai-input/ai-train reservations under EU DSM
  Art.4) + no server-rendered catalog (18KB shell). Respect the signal; skip.
- dramapops.com: landing page only (114-byte home, 1-URL sitemap /lander, llms.txt "Disallow-Training"). No catalog.
- shortstv.com: the traditional ShortsTV short-FILM channel, not the vertical-drama app. Not our target.
- flickreels.com / gammatime.com / veloria.com(.tv): do not resolve on guessed domains (dead or app-only). Unknown real domain.
